let music = prompt(
  "If you like Pakistani music, or Indian music? (yes/no/both/neither)"
);
if (music === "yes") {
  console.log("Aap ko Pakistani music pasand hai!");
} else if (music === "no") {
  console.log("Aap ko Indian music pasand hai!");
} else if (music === "both") {
  console.log("Aap ko dono Pakistani aur Indian music pasand hai!");
} else {
  console.log("Aapke music taste international hai!");
}
