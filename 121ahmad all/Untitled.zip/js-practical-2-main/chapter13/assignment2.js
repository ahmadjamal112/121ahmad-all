let language = +prompt("How many languages do you speak?");
if (language == 1) {
  console.log("You speak one language!");
} else if (language > 1) {
  console.log("Aap ko zubaan ka ilm bohot ziada hai");
}
