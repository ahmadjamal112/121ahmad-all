let day = prompt("Kia aaj Eid ka din hai? (Yes/No)");
if (day === "Yes" || day === "yes") {
  console.log("Eid Mubarak! Aap ka ghar ma kya khana ban raha hai?");
} else {
  console.log("let wait for Eid day");
}
