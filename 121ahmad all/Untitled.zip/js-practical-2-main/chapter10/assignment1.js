let bike = prompt("Aap ka pass bike hai? (Yes/No)");
if (bike === "Yes" || bike === "yes") {
  let bikeModel = +prompt("Aap ki bike kitni purani hai");
  let use = prompt("kia aap bike roz use karta hai (Yes/No)");
  if ((bikeModel > 5 && use === "Yes") || use === "yes") {
    console.log("Aap ko bike bechni chahiye");
  } else {
    console.log("Aap khyal sa rakhy kara bike ka");
  }
} else {
  console.log("Aap ko bike khareedni chahiye");
}
