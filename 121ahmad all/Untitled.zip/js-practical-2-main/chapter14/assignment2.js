let membership = prompt("Enter membership status: (platinum/gold/silver) ");
let price = +prompt("Enter price: ");

if (membership == "platinum" || membership == "gold") {
  if (price >= 1000) {
    console.log("you are eligible for discount");
  } else {
    console.log("you are not eligible for discount");
  }
} else {
  console.log("you are not eligible for discount");
}
