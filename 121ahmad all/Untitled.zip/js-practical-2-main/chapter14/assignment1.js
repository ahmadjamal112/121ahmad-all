let age = +prompt("Enter your age: ");
let grade = +prompt("Enter your grade level: ");
let gpa = +prompt("Enter your GPA: ");

if (age >= 17) {
  if (grade == 11 || grade == 12) {
    if (gpa >= 3.5) {
      console.log("You are eligible to apply for the scholarship");
    } else {
      console.log(
        "You are not eligible to apply for the scholarship your gpa don't meet the requirement"
      );
    }
  } else {
    console.log(
      "You are not eligible to apply for the scholarship your grade level don't meet the requirement"
    );
  }
} else {
  console.log(
    "You are not eligible to apply for the scholarship your age don't meet the requirement"
  );
}
