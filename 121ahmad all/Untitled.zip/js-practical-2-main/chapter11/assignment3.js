let drivingLicense = prompt("Do you have a driving license? (yes/no) ");
if (drivingLicense === "no") {
  if (!false) {
    console.log("Aap ke paas driving license nahi hai.");
  }
} else {
  console.log("Aap ke paas driving license hai.");
}
