let city = prompt("Enter your favorite Pakistani city: ");
if (city === "Karachi" || city === "Lahore") {
  console.log("Aap ka pasandida shehar Karachi ya Lahore hai.");
} else {
  console.log("Aap ka pasandida shehar Karachi ya Lahore nahi hai.");
}
