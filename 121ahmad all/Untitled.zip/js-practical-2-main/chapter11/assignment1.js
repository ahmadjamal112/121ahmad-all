let userAge = prompt("Enter your age: ");
let material = prompt("Enter your matirial status: (single/married) ");

if (userAge > 25 && material === "married") {
  console.log(`Aap shadi shuda hain aur aap ${userAge} saal ke hain.`);
} else if (userAge > 18 && material === "single" && userAge < 25) {
  console.log(`Aap single hain aur aap ${userAge} saal ke hain shadi kar la.`);
} else {
  console.log("Aap bachay hain.");
}
