let food = prompt("What is your favorite Pakistani food?");
console.log(`Maza aayega! Apka khaana taiyaar hai!`);
