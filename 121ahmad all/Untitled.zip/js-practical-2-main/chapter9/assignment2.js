let yourName = prompt("What is your name?");
let yourCity = prompt("What city do you live in?");

console.log(`Assalamu Alaikum, Apka sheher kaisa hai?`);
