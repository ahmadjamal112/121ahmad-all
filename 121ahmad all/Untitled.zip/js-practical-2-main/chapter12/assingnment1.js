let city = prompt("What is your fav. Pakistani city");
let size = prompt("Is your city big");
if (city === "Karachi" || (city === "karachi" && size == "big")) {
  console.log("Aapke sheher ki khubsurati tho alag hai");
} else if (city === "Lahore" || (city === "lahore" && size == "big")) {
  console.log("Aapke sheher ki khubsurati tho alag hai");
} else if (city === "Islamabad" || (city === "islamabad" && size == "big")) {
  console.log("Aapke sheher ki khubsurati tho alag hai");
} else {
  console.log("you live in in small city");
}
