let siblings = prompt("How many siblings do you have?");
if (siblings > 5) {
  console.log("You have a big family!");
} else if (siblings >= 3 && siblings <= 5) {
  console.log("You have a medium family!");
} else {
  console.log("You have a small family!");
}
